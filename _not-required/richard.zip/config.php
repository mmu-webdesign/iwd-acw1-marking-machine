<?php

// MAKE SURE EVERYTHING IS GOING THROUGH HTTPS!!!!!!!!


$unit_name = "Introduction to Web Development"; // add unit name here

$student_list = 'iwd-acw2-2020.csv';
// include trailing slash
// e.g. http://www.[student id].webdevmmu.uk/
$check_url = 'http://localhost/marking-app-acw2-iwd/student-sites/iwd-2020/[id]/';

$jpg_file_size = 120000; // 120k
